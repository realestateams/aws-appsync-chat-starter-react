const env = require('process').env;
const fetch = require('node-fetch');
const URL = require('url');
const AWS = require('aws-sdk');

AWS.config.update({
    region: env.AWS_REGION,
    credentials: new AWS.Credentials(env.AWS_ACCESS_KEY_ID, env.AWS_SECRET_ACCESS_KEY, env.AWS_SESSION_TOKEN)
});
// , 


exports.handler = async (event, context, callback) => {
    console.log('redirect-lambda', event)

    console.log(`Event = ${JSON.stringify(event, null, 2)}`);
    console.log(`Env = ${JSON.stringify(env, null, 2)}`);

    const GetUser = `query GetUser($userId: String, $userName: String){
        getUser(body:{id: $userId, username: $userName}) {
            id
            username
        }
    }`;

    const details = {
        userId: "abc",
        userName: "aaa"
    };

    const post_body = {
        query: GetUser,
        operationName: 'GetUser',
        variables: details
    };
    console.log(`Posting: ${JSON.stringify(post_body, null, 2)}`);

    // POST the GraphQL mutation to AWS AppSync using a signed connection
    let graphqlApiUrl = "https://go7u5q3ckfbdbatu3gh3zajnoy.appsync-api.eu-west-2.amazonaws.com/graphql";
    const uri = URL.parse(graphqlApiUrl);
    const httpRequest = new AWS.HttpRequest(uri.href, env.REGION);
    httpRequest.headers.host = uri.host;
    httpRequest.headers['Content-Type'] = 'application/json';
    httpRequest.method = 'POST';
    httpRequest.body = JSON.stringify(post_body);

    AWS.config.credentials.get(err => {
        const signer = new AWS.Signers.V4(httpRequest, "appsync", true);
        // const awsCredentials = {
        //     accessKeyId: env.AWS_ACCESS_KEY_ID,
        //     secretAccessKey: env.AWS_SECRET_ACCESS_KEY
        // }
        console.log(`signer.addAuthorization: ${JSON.stringify(AWS.config.credentials, null, 2)}`);
        
        signer.addAuthorization(AWS.config.credentials, AWS.util.date.getDate());
        console.log(`FETCH REF and OPTIONS ${uri.href} ${JSON.stringify(options, null, 2)}`);

        const options = {
            method: httpRequest.method,
            body: httpRequest.body,
            headers: httpRequest.headers
        };

        fetch(uri.href, options)
            .then(res => {
                console.log(`fetch rest ${res}`);
                return res.json()
            })
            .then(json => {
                console.log(`JSON Response = ${JSON.stringify(json, null, 2)}`);
                callback(null, event);
            })
            .catch(err => {
                console.error(`FETCH ERROR: ${JSON.stringify(err, null, 2)}`);
                callback(err);
            });
    });

    // const response = {
    //     statusCode: 301,
    //     headers: {
    //         Location: 'https://google.com'
    //     }
    // }
    
    // return response
};