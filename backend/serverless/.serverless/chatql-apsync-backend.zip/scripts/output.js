function handler(data) {
  // eslint-disable-next-line
  console.log('Received Stack Output', data)
}

module.exports = { handler }
